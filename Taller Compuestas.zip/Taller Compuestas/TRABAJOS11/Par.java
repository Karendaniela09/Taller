package TRABAJOS11;

public class Par {
    public static void main(String[] args) {

        int numero = 7;

        if (numero == 0) {
            System.out.println("el numero es cero");
        } else if (numero % 2 == 0) {
            System.out.println("el numero es par");
        } else {
            System.out.println("el numero es impar");
        }
    }

    
}
