package TRABAJOS11;

public class Mayor { 
    public static void main(String[] args) {
    int one = 10;
    int two = 10;

    if (one > two) {
        System.out.println("el numero mayor es " + one);
    } else if (two > one) {
        System.out.println("el numero mayor es " + two);
    } else {
        System.out.println("los numeros son iguales");
    }
}
    
}
