package TRABAJOS11;

public class Numeros {
    public static void main(String[] args) {

        int numero = -5;

        if (numero > 0) {
            System.out.println("el numero es positivo");
        } else if (numero < 0) {
            System.out.println("el numero es negativo");
        } else {
            System.out.println("el numero es cero");
        }
    }
}
