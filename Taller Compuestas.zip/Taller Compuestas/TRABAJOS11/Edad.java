package TRABAJOS11;
public class Edad {
    public static void main(String[] args) {
        int edad = 18;

        if (edad > 18) {
            System.out.println("es mayor de edad");
        } else if (edad == 18) {
            System.out.println("tiene exactamente 18 años");
        } else {
            System.out.println("es menor de edad");
        }
        
    }

    
}
