package TRABAJOS11;

public class AccessoSistema {
    public static void main(String[] args) {
        String usuario = "admin";
        String contrasena = "68394";

        if (usuario.equals("admin") && contrasena.equals("68394")) {
            System.out.println("Acceso concedido");
        } else {
            System.out.println("Acceso denegado");
        }
    }
}

