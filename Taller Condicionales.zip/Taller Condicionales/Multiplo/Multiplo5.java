/* 
 * Multiplo de 5: Verifica si un número ingresado es múltiplo de 5.
 */

package Multiplo;

public class Multiplo5 {
    int numero = 25;

    public static void main(String[] args) {
        Multiplo5 obj = new Multiplo5();
        obj.verificarMultiplo();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void verificarMultiplo() {
        if (numero % 5 == 0) {
            System.out.println("es múltiplo de 5: " + numero);
        } else {
            System.out.println("no es múltiplo de 5");
        }
    }
}
