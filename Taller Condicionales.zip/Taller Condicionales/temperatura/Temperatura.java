/*
 * Temperatura alta: Pide una temperatura y muestra si está por encima de 30°C.
 */

package temperatura;

public class Temperatura {
    int temperatura = 35;

    public static void main(String[] args) {
        Temperatura obj = new Temperatura();
        obj.verificarTemperatura();
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    public void verificarTemperatura() {
        if (temperatura > 30) {
            System.out.println("temperatura alta: " + temperatura + "°C");
        } else {
            System.out.println("temperatura normal");
        }
    }
}





    

