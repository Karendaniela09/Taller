/*
 * Divisible por 3: Pide un número e indica si es divisible entre 3
 */
package temperatura;

public class Divisible {

    public static void main(String[] args) {
        Divisible obj= new Divisible3(); 
        obj.verificarDivisible(); 
    }

    private void verificarDivisible() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'verificarDivisible'");
    }
}
