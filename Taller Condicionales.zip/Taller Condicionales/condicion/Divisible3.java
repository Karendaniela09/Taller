/*
 * Número par: Indica si un número ingresado es par.
 */
package condicion;

public class Divisible3 {
    int numero = 9;

    public static void main(String[] args) {
        Divisible3 obj = new Divisible3();
        obj.verificarDivisible();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void verificarDivisible() {
        if (numero % 3 == 0) {
            System.out.println("es divisible entre 3: " + numero);
        } else {
            System.out.println("no es divisible entre 3");
        }
    }
}
