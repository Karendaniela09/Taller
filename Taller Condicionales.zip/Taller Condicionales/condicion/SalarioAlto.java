/*
 * Salario alto: Pide un salario mensual y muestra si supera los $3000.
 */
package condicion;

public class SalarioAlto {
    double salario = 3200.0;

    public static void main(String[] args) {
        SalarioAlto obj = new SalarioAlto();
        obj.verificarSalario();
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void verificarSalario() {
        if (salario > 3000) {
            System.out.println("salario alto: $" + salario);
        } else {
            System.out.println("salario no es alto");
        }
    }
}
