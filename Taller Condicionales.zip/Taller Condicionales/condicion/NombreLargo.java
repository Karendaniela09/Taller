/*
 * Nombre largo: Pide un nombre e indica si tiene más de 8 caracteres.
 */
package condicion;

public class NombreLargo {
    String nombre = "Sebastian";

    public static void main(String[] args) {
        NombreLargo obj = new NombreLargo();
        obj.verificarNombre();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void verificarNombre() {
        if (nombre.length() > 8) {
            System.out.println("el nombre es largo: " + nombre);
        } else {
            System.out.println("el nombre no es largo");
        }
    }
}
