/*
 * Mayor de edad: Solicita la edad e imprime si la persona es mayor de edad.
 */

 package condicion;

public class MayorEdad {
    int edad = 20;

    public static void main(String[] args) {
        MayorEdad obj = new MayorEdad();
        obj.verificarEdad();
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void verificarEdad() {
        if (edad >= 18) {
            System.out.println("es mayor de edad: " + edad);
        } else {
            System.out.println("es menor de edad");
        }
    }
}







    

