/*
 * Nota aprobada: Ingresa una nota y muestra si es mayor o igual a 10 (aprobado).
 */

package edad;

public class Nota {
    int nota = 15;

    public static void main(String[] args) {
        Nota obj = new Nota();
        obj.verificarNota();
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public void verificarNota() {
        if (nota >= 10) {
            System.out.println("aprobado con nota: " + nota);
        } else {
            System.out.println("reprobado con nota: " + nota);
        }
    }
}


