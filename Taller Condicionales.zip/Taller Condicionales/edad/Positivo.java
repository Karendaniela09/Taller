/* 
 * Número positivo: Lee un número y muestra si es positivo.
 */


package edad;

public class Positivo {
    int numero = 5;

    public static void main(String[] args) {
        Positivo obj = new Positivo();
        obj.verificarNumero();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void verificarNumero() {
        if (numero > 0) {
            System.out.println("es positivo: " + numero);
        } else {
            System.out.println("no es positivo");
        }
    }
}

