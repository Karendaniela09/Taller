/* 
 * Edad para votar: Pide al usuario su edad e indica si puede votar (mayor o igual a 18 años).
 */
package edad;
public class Edad {
    public static void main(String[] args) { 
    }
    int Edad=18;
    public int getEdad() {
        return Edad;
    }
    
    ( Edad>= 18 ) {
    System.out.println("es mayor de edad, puede votar="+Edad);
  } else {
    System.out.println("es menor de edad");
  }
  public void setEdad(int edad) {
    Edad = edad;
  }
    
  
    }

